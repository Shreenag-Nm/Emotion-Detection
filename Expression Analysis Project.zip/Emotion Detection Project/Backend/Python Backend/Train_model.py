import cv2
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dense, Dropout, Flatten
from keras.optimizers import Adam
from keras.preprocessing.image import ImageDataGenerator
import scipy

# Data Augmentation for Training and Validation
train_data = ImageDataGenerator(rescale=1./255)
validate_data = ImageDataGenerator(rescale=1./255)

# Data Generators for Training and Validation
train_gen = train_data.flow_from_directory(
    'E:/1_MCA/FINAL_YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Emotion_detection_with_CNN-main/train',
    target_size=(48, 48),
    batch_size=64,
    color_mode="grayscale",
    class_mode='categorical'
)

validate_gen = validate_data.flow_from_directory(
    'E:/1_MCA/FINAL_YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Emotion_detection_with_CNN-main/test',
    target_size=(48, 48),
    batch_size=64,
    color_mode="grayscale",
    class_mode='categorical'
)

# Define the CNN Model
emo_model = Sequential()

# Convolutional Layers (Feature Extraction)
emo_model.add(Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(48, 48, 1)))
emo_model.add(Conv2D(64, kernel_size=(3, 3), activation='relu'))
emo_model.add(MaxPooling2D(pool_size=(2, 2)))
emo_model.add(Dropout(0.25))  # Reduce overfitting

emo_model.add(Conv2D(128, kernel_size=(3, 3), activation='relu'))
emo_model.add(MaxPooling2D(pool_size=(2, 2)))
emo_model.add(Conv2D(128, kernel_size=(3, 3), activation='relu'))
emo_model.add(MaxPooling2D(pool_size=(2, 2)))
emo_model.add(Dropout(0.25))  # Reduce overfitting

# Flatten Layer for Dense Connections
emo_model.add(Flatten())

# Dense Layers (Classification)
emo_model.add(Dense(1024, activation='relu'))
emo_model.add(Dropout(0.5))  # Reduce overfitting
emo_model.add(Dense(7, activation='softmax'))  # 7 output classes (assuming 7 emotions)

# Disable OpenCL (optional, depending on hardware/performance)
cv2.ocl.setUseOpenCL(False)

# Compile the Model
emo_model.compile(loss='categorical_crossentropy', optimizer=Adam(lr=0.0001, decay=1e-6), metrics=['accuracy'])

# Train the Model
train_emo = emo_model.fit_generator(
    train_gen,
    steps_per_epoch=28709 // 64,  # Adjust steps_per_epoch based on actual training data size
    epochs=20,
    validation_data=validate_gen,
    validation_steps=7178 // 64   # Adjust validation_steps based on actual validation data size
)

# Save Model Architecture and Weights
emo_json = emo_model.to_json()
with open("Emotion_test_model.json", "w") as json_file:
    json_file.write(emo_json)
emo_model.save_weights('Emo_model.h5')
