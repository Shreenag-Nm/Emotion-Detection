<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signupdb";
$conn = new mysqli($servername, $username, $password,
$dbname);
if ($conn->connect_error) {
die("Connection failed: " . $conn-
>connect_error);
}
$firstName = $_POST['first-name'];
$lastName = $_POST['last-name'];
$dateOfBirth = $_POST['date-of-birth'];
$gender = $_POST['gender'];
$phoneNumber = $_POST['phone_number'];
$email = $_POST['email'];
$password = $_POST['password'];
$hashedPassword = password_hash($password,
PASSWORD_DEFAULT);
$sql = "INSERT INTO connection (first_name,
last_name, date_of_birth, gender,phone, email,
password)
VALUES ('$firstName', '$lastName',
'$dateOfBirth', '$gender', '$phoneNumber', '$email',
'$hashedPassword')";
if ($conn->query($sql) === TRUE) {
header("Location:login_page.html");
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>