from flask import Flask, render_template
import subprocess
import os

app = Flask(__name__, static_folder='static')

@app.route('/')
@app.route('/index')
def index():
    return render_template('Flask_home.html')

@app.route('/get_report')
def get_report():
    return render_template('get_report.html')

@app.route('/start_detection')
def start_detection():
    script_path = os.path.abspath('E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Train_model.py')
    subprocess.run(['python', script_path])
    genrate_report()
    return "Face Detection Started!"

def genrate_report():
    script = os.path.abspath('E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/csv_plot.py')
    subprocess.run(['python', script])
    print("Report generated")

if __name__ == '__main__':
    app.run(debug=False)
