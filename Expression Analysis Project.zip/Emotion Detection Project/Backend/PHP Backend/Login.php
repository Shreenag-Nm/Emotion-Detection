<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signupdb";
$conn = new mysqli($servername, $username, $password,
$dbname);
if ($conn->connect_error) {
die("Connection failed: " . $conn-
>connect_error);
}
// Retrieve user input
$email = $_POST['email'];
$password = $_POST['password'];
// Sanitize user input
$email = mysqli_real_escape_string($conn, $email);
// Retrieve user from database based on email
$sql = "SELECT * FROM connection WHERE email =
'$email'";
$result = $conn->query($sql);
if ($result->num_rows == 1) {
// User found, compare the password
$row = mysqli_fetch_assoc($result);
$storedPassword = $row['password'];
if (password_verify($password, $storedPassword))
{
// Password matches, login successful
// header("Location:
http://localhost/Working/Python/Flask_support/templat
es/Flask_home.html");
$flaskUrl = 'http://127.0.0.1:5000'; // Adjust
the URL to your Flask server
header("Location: $flaskUrl");
exit();

} else {
// Password does not match
// echo "Invalid password! Stored:
$storedPassword | Input: " . password_hash($password,
PASSWORD_DEFAULT);
header("Location: invalid_password.html");
}
} else {
// User not found
echo "User not found!";
}
$conn->close();
?>