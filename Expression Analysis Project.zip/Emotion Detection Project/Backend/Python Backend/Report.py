import pandas as pd
import matplotlib.pyplot as plt
import os

# Specify the full path to your CSV file
csv_file_path = 'E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Flask_support/data/EMO_RECORDS.csv'

# Read the CSV file
df = pd.read_csv(csv_file_path)

# Calculate emotion counts
emotion_counts = df['Emotion'].value_counts()

# Create a pie chart
plt.figure(figsize=(8, 8))
plt.pie(emotion_counts, labels=emotion_counts.index, autopct='%1.1f%%', startangle=140)
plt.title('Emotion Distribution')
plt.axis('equal')

# Specify the full path to the folder where you want to save the image
static_folder = 'E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Flask_support/static'

# Create the static folder if it doesn't exist
if not os.path.exists(static_folder):
    os.makedirs(static_folder)

# Specify the full path to save the image
png_file = os.path.join(static_folder, 'emotion_chart.png')

# Check if the file already exists and remove it
if os.path.exists(png_file):
    os.remove(png_file)

# Save the pie chart as an image
plt.savefig(png_file)
