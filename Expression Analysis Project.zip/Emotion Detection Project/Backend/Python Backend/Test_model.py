import cv2
import numpy as np
from keras.models import model_from_json
import csv
import datetime
import os

emo_dict = {0: "Angry", 1: "Disgusted", 2: "Fearful", 3: "Happy",
            4: "Neutral", 5: "Sad", 6: "Surprised"}

# Load model architecture and weights
json_file = open('E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Emotion_test_model.json', 'r')
load_json = json_file.read()
json_file.close()
emo_model = model_from_json(load_json)
emo_model.load_weights("E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Emo_model.h5")
print("Loaded Model From The Disk")

cap = cv2.VideoCapture(0)

# Specify the path to the "data" folder
data_folder = 'E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Flask_support/data'

# Ensure the "data" folder exists
if not os.path.exists(data_folder):
    os.makedirs(data_folder)

# Specify the path to the CSV file in the "data" folder
csv_file_path = os.path.join(data_folder, 'EMO_RECORDS.csv')

# Check if the CSV file already exists and delete it
if os.path.exists(csv_file_path):
    os.remove(csv_file_path)

print(f"Deleted {csv_file_path}")

# Open the CSV file for writing
csv_file = open(csv_file_path, 'w', newline='')
csv_writer = csv.writer(csv_file)
csv_writer.writerow(['Timestamp', 'Emotion'])

while True:
    ret, frame = cap.read()
    frame = cv2.resize(frame, (1280, 720))
    if not ret:
        break

    face_dec = cv2.CascadeClassifier("E:/1_MCA FINAL YEAR/PROJECT/Xampp_Support/htdocs/Working/Python/Emotion_detection_with_CNN-main/haarcascades/haarcascade_frontalface_default.xml")
    gr_fr = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    num_face = face_dec.detectMultiScale(gr_fr, scaleFactor=1.3, minNeighbors=5)
    for (x, y, w, h) in num_face:
        cv2.rectangle(frame, (x, y - 50), (x + w, y + h + 10), (0, 255, 0), 4)

        roi_gray_frame = gr_fr[y:y + h, x:x + w]
        cropped_img = np.expand_dims(np.expand_dims(cv2.resize(roi_gray_frame, (48, 48)), -1), 0)

        # Predict the emotion
        emo_prediction = emo_model.predict(cropped_img)
        maxindex = int(np.argmax(emo_prediction))
        pre_emo = emo_dict[maxindex]

        time_stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        csv_writer.writerow([time_stamp, pre_emo])

        cv2.putText(frame, emo_dict[maxindex], (x + 5, y - 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

    cv2.imshow('Emotion Detection', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

csv_file.close()
cap.release()
cv2.destroyAllWindows()
